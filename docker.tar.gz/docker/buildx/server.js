const http = require('http)

const hostname='0.0.0.0'
const port=8080;

const server
