package main

import "fmt"

Func man(){
	fmt.Print("Hello go~!! \n")
}
