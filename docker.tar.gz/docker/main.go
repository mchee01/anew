package main

import "fmt"

Func main(){
	fmt.Print("Hello go~!! \n")
}
